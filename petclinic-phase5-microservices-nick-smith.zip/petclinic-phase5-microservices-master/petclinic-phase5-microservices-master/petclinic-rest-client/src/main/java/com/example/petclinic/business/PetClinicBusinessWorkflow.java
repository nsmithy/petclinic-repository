package com.example.petclinic.business;


import com.example.petclinic.model.Owner;
import com.example.petclinic.service.OwnerService;


public class PetClinicBusinessWorkflow {

    OwnerService ownerService;

    Owner owner;

    public PetClinicBusinessWorkflow(OwnerService ownerService) {
        this.ownerService = ownerService;
    }


    // TODO add business stuff here

    public void runBusiness(){

        Owner owner1 = Owner.builder().withName("Homer Simpson").withAddress("742 Evergreen Terrace").withCity("Springfield").withPhoneNumber("123456789");
        Owner owner2 = Owner.builder().withName("Marge Simpson").withAddress("742 Evergreen Terrace").withCity("Springfield").withPhoneNumber("123456789");
        Owner owner3 = Owner.builder().withName("Bart Simpson").withAddress("742 Evergreen Terrace").withCity("Springfield").withPhoneNumber("123456789");
        Owner owner4 = Owner.builder().withName("Lisa Simpson").withAddress("742 Evergreen Terrace").withCity("Springfield").withPhoneNumber("123456789");





    }



}
