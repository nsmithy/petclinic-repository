package com.example.petclinic.service;


import com.example.petclinic.model.Owner;

import org.slf4j.LoggerFactory;
import org.springframework.web.client.RestTemplate;

import java.net.URI;


import java.util.logging.Logger;

public class OwnerService {

    public static final Logger log = (Logger) LoggerFactory.getLogger(OwnerService.class);

    RestTemplate restTemplate;

    public OwnerService(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    public Owner saveOwner(Owner owner){

        URI uri = URI.create("http://localhost:8080/ownerapi/owner/addOwner");

        Owner response = restTemplate.postForObject(uri, owner, Owner.class);


        log.info(response.toString());
        return response;
    }


}
