package com.example.petclinic;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PetClinicVisit {

    public static void main(String[] args) {

        SpringApplication.run(PetClinicVisit.class, args);
    }
}
