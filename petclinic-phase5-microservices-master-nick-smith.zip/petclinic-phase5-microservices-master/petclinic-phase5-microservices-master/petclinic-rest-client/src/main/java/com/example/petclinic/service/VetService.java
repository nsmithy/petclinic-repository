package com.example.petclinic.service;


import com.example.petclinic.model.Vet;

import org.slf4j.LoggerFactory;
import org.springframework.web.client.RestTemplate;

import java.net.URI;


import java.util.logging.Logger;

public class VetService {

    public static final Logger log = (Logger) LoggerFactory.getLogger(VetService.class);

    RestTemplate restTemplate;

    public VetService(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    public Vet saveVet(Vet vet){

        URI uri = URI.create("http://localhost:8080/vetapi/vet/addVet");

        Vet response = restTemplate.postForObject(uri, vet, Vet.class);


        log.info(response.toString());
        return response;
    }


}
