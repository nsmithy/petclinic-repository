package com.example.petclinic.business;


import com.example.petclinic.model.Owner;
import com.example.petclinic.service.OwnerService;
import com.example.petclinic.service.VetService;
import org.springframework.stereotype.Component;


@Component
public class PetClinicBusinessWorkflow {

    OwnerService ownerService;


    VetService vetservice;


    public PetClinicBusinessWorkflow(OwnerService ownerService) {
        this.ownerService = ownerService;
    }


    // TODO add business stuff here

    public void runBusiness(){
        //Create Owners
        Owner owner1 = Owner.builder().withName("Homer Simpson").withAddress("742 Evergreen Terrace").withCity("Springfield").withPhoneNumber("123456789").build();
        Owner owner2 = Owner.builder().withName("Marge Simpson").withAddress("742 Evergreen Terrace").withCity("Springfield").withPhoneNumber("123456789").build();
        Owner owner3 = Owner.builder().withName("Bart Simpson").withAddress("742 Evergreen Terrace").withCity("Springfield").withPhoneNumber("123456789").build();
        Owner owner4 = Owner.builder().withName("Lisa Simpson").withAddress("742 Evergreen Terrace").withCity("Springfield").withPhoneNumber("123456789").build();

        ownerService.add(owner1);
        ownerService.add(owner2);
        ownerService.add(owner3);
        ownerService.add(owner4);



    }



}
